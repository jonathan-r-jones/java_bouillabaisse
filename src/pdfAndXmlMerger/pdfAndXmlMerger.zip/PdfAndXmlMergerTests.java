package pdfAndXmlMerger;

import org.junit.Test;

public class PdfAndXmlMergerTests
{
String data_path = "C:\\Users\\jonathan.r.jones\\Documents\\Dropbox\\NES\\Eclipse Workspace\\$UnderDevelopment\\src\\pdfAndXmlMerger\\Test Data\\";
PdfAndXmlMerger pdfAndXmlMerger = new PdfAndXmlMerger();

@Test
public void test22()
{
	// Function Purpose: Test the BFO merge with a little more data.xml.
	// Creation Date: Nov-14-2016
	// Outcome: Worked.
	// This is the latest.
	String templatePDFFilename = data_path + "1234_data.pdf";
	String xmlDataFilename = data_path + "a little more data 2.xml";
	String codeGeneratedPdfFilename = data_path + "1234_a_little_more_data_2_Merge.pdf";
	pdfAndXmlMerger.createPdf3(templatePDFFilename, xmlDataFilename, codeGeneratedPdfFilename);
}
}
